"""FinSight Flask dashboard package."""
