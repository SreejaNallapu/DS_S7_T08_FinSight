"""FinSight application package."""

